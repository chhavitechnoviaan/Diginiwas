import mongoose from "mongoose";

const COLLECTION_NAME = "newproperties";

const escapeRegex = (value = "") =>
  String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const toTitleRole = (role = "") => {
  const value = String(role || "").trim().toLowerCase();
  if (value === "admin") return "Admin";
  if (value === "partner") return "Partner";
  if (value === "seller" || value === "owner") return "Seller";
  if (value === "agent") return "Agent";
  return role || "";
};

const normalizeTransactionType = (doc) => {
  const listing = String(doc?.listingType || "").trim().toLowerCase();
  const transaction = String(doc?.transactionType || "").trim().toLowerCase();

  if (listing === "rent" || transaction === "rent" || transaction === "lease") return "Rent";
  if (listing === "sell" || listing === "sale") return "Sale";
  if (["resale", "new booking", "new project", "new booking"].includes(transaction)) return "Sale";
  if (transaction === "sale") return "Sale";
  return doc?.transactionType || "";
};

const normalizePropertyType = (doc) => {
  const direct = String(doc?.propertyType || "").trim();
  if (direct) return direct;

  const category = String(doc?.category || "").trim().toLowerCase();
  if (category === "plot/land" || category === "plot" || category === "land") return "Plot";
  if (category === "residential") return "Residential";
  if (category === "commercial") return "Commercial";

  // Rent/Sale are transaction categories, not property types.
  // When propertyType is missing, prefer the building/type field instead
  // of showing values like "Rent" as the property type in the UI.
  if (["rent", "rental", "lease", "sell", "sale", "resale"].includes(category)) {
    return doc?.buildingType || doc?.type || "";
  }

  return doc?.category || "";
};

const normalizePrice = (doc) => {
  if (typeof doc?.price === "number") return doc.price;
  if (doc?.price && typeof doc.price === "object") return Number(doc.price.amount || 0);
  if (doc?.rent && typeof doc.rent === "object") return Number(doc.rent.amount || 0);
  return Number(doc?.price || 0);
};

const normalizeImages = (doc) => {
  const source = Array.isArray(doc?.images)
    ? doc.images
    : Array.isArray(doc?.media?.images)
      ? doc.media.images
      : [];

  return source
    .map((image) => {
      if (typeof image === "string") return { url: image };
      return {
        ...image,
        url: image?.url || image?.secure_url || "",
        public_id: image?.public_id || image?.publicId || "",
      };
    })
    .filter((image) => image.url);
};

export const normalizeUnifiedProperty = (doc = {}) => {
  const location = doc.location || {};
  const createdBy = doc.createdBy || {};
  const addedBy = doc.addedBy || {};
  const role = toTitleRole(addedBy.role || createdBy.role);
  const city = doc.city || location.city || "";
  const locality = doc.locality || location.locality || "";
  const address = doc.address || location.address || "";
  const pinCode = doc.pinCode || location.pinCode || "";
  const latitude = doc.latitude ?? location.latitude ?? null;
  const longitude = doc.longitude ?? location.longitude ?? null;
  const propertyType = normalizePropertyType(doc);
  const transactionType = normalizeTransactionType(doc);
  const price = normalizePrice(doc);
  const displayedArea = Array.isArray(doc.areaDetails)
    ? (doc.areaDetails.find((area) => area?.display) || doc.areaDetails[0])
    : null;
  const maintenanceAmount = typeof doc.maintenance === "number"
    ? doc.maintenance
    : Number(doc.maintenance?.amount || 0);
  const negotiable = doc.negotiable ?? doc.price?.negotiable ?? doc.rent?.negotiable ?? false;

  const normalized = {
    ...doc,
    sourceModel: doc.sourceModel || "NewProperty",
    propertyId: doc.propertyId || String(doc._id || ""),
    title: doc.title || "Untitled Property",
    transactionType,
    listingType: doc.listingType || transactionType,
    category: doc.category || (propertyType === "Plot" ? "Plot/Land" : ""),
    propertyType,
    buildingType: doc.buildingType || "",
    status: doc.status || "Draft",
    propertyVerificationStatus: doc.propertyVerificationStatus || "Pending",
    city,
    state: doc.state || location.state || "",
    country: doc.country || location.country || "India",
    locality,
    address,
    pinCode,
    latitude: latitude === null || latitude === "" ? null : Number(latitude),
    longitude: longitude === null || longitude === "" ? null : Number(longitude),
    price,
    propertySize: doc.propertySize ?? displayedArea?.value ?? "",
    sizeUnit: doc.sizeUnit || displayedArea?.unit || "sqft",
    pricePerSqft: doc.pricePerSqft ?? doc.price?.pricePerSqFt ?? null,
    projectName: doc.projectName || location.society || "",
    developerName: doc.developerName || "",
    maintenance: maintenanceAmount || "",
    bookingAmount: doc.bookingAmount ?? "",
    negotiable: Boolean(negotiable),
    superBuiltupArea: doc.superBuiltupArea ?? "",
    carpetArea: doc.carpetArea ?? "",
    bedrooms: doc.bedrooms || doc.bhk || "",
    bathrooms: doc.bathrooms ?? doc.specifications?.bathrooms ?? "",
    balconies: doc.balconies ?? doc.specifications?.balconies ?? "",
    parking: doc.parking ?? (Number(doc.specifications?.coveredParking || 0) + Number(doc.specifications?.openParking || 0)),
    floorNo: doc.floorNo ?? doc.specifications?.propertyFloor ?? "",
    totalFloors: doc.totalFloors ?? doc.specifications?.totalFloorCount ?? "",
    facing: doc.facing || doc.specifications?.facing || "",
    furnishing: doc.furnishing?.status || doc.furnishing || "",
    furnishingDetails: doc.furnishing || null,
    amenities: Array.isArray(doc.amenities) ? doc.amenities : [],
    propertyHighlights: Array.isArray(doc.propertyHighlights) ? doc.propertyHighlights : [],
    additionalSpaces: Array.isArray(doc.additionalSpaces) ? doc.additionalSpaces : [],
    suitedFor: Array.isArray(doc.suitedFor) ? doc.suitedFor : [],
    areaDetails: Array.isArray(doc.areaDetails) ? doc.areaDetails : [],
    availability: doc.availability || null,
    specifications: doc.specifications || {},
    images: normalizeImages(doc),
    media: doc.media || { images: [], videos: [] },
    floorPlan: typeof doc.floorPlan === "string" ? doc.floorPlan : doc.floorPlan?.url || "",
    reraCertificate: typeof doc.reraCertificate === "string" ? doc.reraCertificate : doc.reraCertificate?.url || "",
    video: doc.video || doc.media?.videos?.[0]?.url || "",
    videoLink: doc.videoLink || doc.media?.videos?.[0]?.url || "",
    documents: Array.isArray(doc.documents) ? doc.documents : [],
    oneLineDescription: doc.oneLineDescription || "",
    description: doc.description || "",
    addedBy: {
      ...(addedBy || {}),
      userId: addedBy.userId || createdBy.id || null,
      role,
      name: addedBy.name || createdBy.name || "",
      email: addedBy.email || createdBy.email || "",
      phone: addedBy.phone || createdBy.phone || "",
    },
  };

  return normalized;
};

export const getPropertyCollection = () => {
  if (!mongoose.connection?.db) {
    throw new Error("Database connection is not ready");
  }
  return mongoose.connection.db.collection(COLLECTION_NAME);
};

export const buildUnifiedAdminQuery = ({ role, status, city, search } = {}) => {
  const clauses = [
    { isActive: { $ne: false } },
    { deletedByAccount: { $ne: true } },
  ];

  if (role && role !== "All") {
    const normalizedRole = String(role).trim().toLowerCase();
    const roleValues = normalizedRole === "seller" ? ["Seller", "seller", "Owner", "owner"] :
      normalizedRole === "partner" ? ["Partner", "partner"] :
      normalizedRole === "admin" ? ["Admin", "admin"] : [];

    if (roleValues.length) {
      clauses.push({
        $or: [
          { "addedBy.role": { $in: roleValues } },
          { "createdBy.role": { $in: roleValues.map((value) => value.toLowerCase()) } },
        ],
      });
    }
  }

  if (status && status !== "All") clauses.push({ status });

  if (city && city !== "All") {
    const rx = new RegExp(escapeRegex(city.trim()), "i");
    clauses.push({ $or: [{ city: rx }, { "location.city": rx }] });
  }

  if (search?.trim()) {
    const rx = new RegExp(escapeRegex(search.trim()), "i");
    clauses.push({ $or: [
      { title: rx }, { propertyId: rx }, { city: rx }, { "location.city": rx },
      { locality: rx }, { "location.locality": rx }, { address: rx }, { "location.address": rx },
      { "addedBy.name": rx }, { "addedBy.partnerId": rx }, { "createdBy.role": rx },
      { propertyType: rx }, { category: rx },
    ] });
  }

  return clauses.length ? { $and: clauses } : {};
};

export const findUnifiedProperties = async (query = {}, options = {}) => {
  const collection = getPropertyCollection();
  const cursor = collection.find(query).sort(options.sort || { createdAt: -1 });
  if (Number.isFinite(options.skip)) cursor.skip(options.skip);
  if (Number.isFinite(options.limit)) cursor.limit(options.limit);
  const docs = await cursor.toArray();
  return docs.map(normalizeUnifiedProperty);
};

export const findUnifiedPropertyById = async (id) => {
  const collection = getPropertyCollection();
  let objectId;
  try {
    objectId = new mongoose.Types.ObjectId(id);
  } catch {
    return null;
  }
  const doc = await collection.findOne({ _id: objectId });
  return doc ? normalizeUnifiedProperty(doc) : null;
};

export const getUnifiedLiveProperties = async ({
  city,
  category,
  propertyType,
  buildingType,
  transactionType,
  minPrice,
  maxPrice,
  bedrooms,
  bathrooms,
  furnishing,
  negotiable,
  search,
  page = 1,
  limit = 100,
} = {}) => {
  const clauses = [
    { status: "Live" },
    { propertyVerificationStatus: "Verified" },
    { isActive: { $ne: false } },
    { deletedByAccount: { $ne: true } },
  ];

  if (city && city !== "All") {
    const rx = new RegExp(`^${escapeRegex(city.trim())}$`, "i");
    clauses.push({ $or: [{ city: rx }, { "location.city": rx }] });
  }

  const requestedType = String(propertyType || "").trim();
  if (requestedType && requestedType !== "All") {
    const rx = new RegExp(`^${escapeRegex(requestedType)}$`, "i");
    clauses.push({ propertyType: rx });
  }

  const requestedBuildingType = String(buildingType || "").trim();
  if (requestedBuildingType && requestedBuildingType !== "All") {
    const rx = new RegExp(`^${escapeRegex(requestedBuildingType)}$`, "i");
    clauses.push({ buildingType: rx });
  }

  if (category && category !== "All") {
    const value = String(category).trim().toLowerCase();
    if (value === "residential" || value === "commercial") {
      clauses.push({ buildingType: new RegExp(`^${escapeRegex(category.trim())}$`, "i") });
    } else if (value === "sell" || value === "sale" || value === "buy") {
      clauses.push({ transactionType: { $in: ["Sale", "Resale", "New Booking"] } });
    } else if (value === "rent" || value === "rental" || value === "lease") {
      clauses.push({ $or: [
        { transactionType: "Rent" },
        { listingType: { $in: ["Rent", "Lease"] } },
      ] });
    } else {
      clauses.push({ category: category });
    }
  }

  if (transactionType && transactionType !== "All") {
    const value = String(transactionType).trim().toLowerCase();
    const aliases = value === "sale" || value === "buy/sell" ? ["Sale", "Sell", "Resale", "New Booking", "New Project"] :
      value === "rent" || value === "lease" ? ["Rent", "Lease"] : [transactionType];
    clauses.push({ $or: [
      { transactionType: { $in: aliases } },
      { listingType: { $in: aliases } },
    ] });
  }

  const min = minPrice !== undefined && minPrice !== "" ? Number(minPrice) : null;
  const max = maxPrice !== undefined && maxPrice !== "" ? Number(maxPrice) : null;
  if (Number.isFinite(min) || Number.isFinite(max)) {
    const range = {};
    if (Number.isFinite(min)) range.$gte = min;
    if (Number.isFinite(max)) range.$lte = max;
    clauses.push({ $or: [{ price: range }, { "price.amount": range }, { "rent.amount": range }] });
  }

  if (bedrooms && bedrooms !== "All") {
    clauses.push({ $or: [{ bedrooms }, { bhk: bedrooms }] });
  }
  if (bathrooms && bathrooms !== "All") {
    clauses.push({ $or: [{ bathrooms }, { "specifications.bathrooms": Number(bathrooms) }] });
  }
  if (furnishing && furnishing !== "All") {
    clauses.push({ $or: [{ furnishing }, { "furnishing.status": furnishing }] });
  }
  if (negotiable === "true" || negotiable === "false") {
    const bool = negotiable === "true";
    clauses.push({ $or: [{ negotiable: bool }, { "price.negotiable": bool }, { "rent.negotiable": bool }] });
  }
  if (search?.trim()) {
    const rx = new RegExp(escapeRegex(search.trim()), "i");
    clauses.push({ $or: [
      { title: rx }, { propertyId: rx }, { city: rx }, { "location.city": rx },
      { locality: rx }, { "location.locality": rx }, { address: rx }, { "location.address": rx },
      { projectName: rx }, { developerName: rx }, { propertyType: rx }, { category: rx },
    ] });
  }

  const query = { $and: clauses };
  const currentPage = Math.max(Number(page) || 1, 1);
  const pageLimit = Math.min(Math.max(Number(limit) || 20, 1), 100);
  const skip = (currentPage - 1) * pageLimit;
  const collection = getPropertyCollection();
  const [docs, total] = await Promise.all([
    collection.find(query).sort({ createdAt: -1 }).skip(skip).limit(pageLimit).toArray(),
    collection.countDocuments(query),
  ]);

  const properties = docs.map(normalizeUnifiedProperty);
  return {
    properties,
    count: properties.length,
    total,
    pagination: { currentPage, totalPages: Math.ceil(total / pageLimit), limit: pageLimit },
    appliedFilters: { city: city || "All", category: category || "All", propertyType: propertyType || "All", buildingType: buildingType || "All", transactionType: transactionType || "All" },
  };
};

